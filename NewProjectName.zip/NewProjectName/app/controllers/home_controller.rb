class HomeController < ApplicationController
	def index
	end
    
    def first
    end
    
    def second
    end
end
