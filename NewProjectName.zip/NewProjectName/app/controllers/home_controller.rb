class HomeController < ApplicationController
  def index
    @ad = {
      title: "大型廣告1",
      des: "這是廣告",
      action_title: "這是廣告",
      }
    @products = [
      {
      id: "1",
      name: "柳橙汁1",
      description: "好喝柳橙汁",
      image_url: "https://images.pexels.com/photos/96974/pexels-photo-96974.jpeg?h=350&auto=compress&cs=tinysrgb",
      },
      
      {
      id: "2",
      name: "柳橙汁2",
      description: "好喝柳橙汁",
      image_url: "https://images.pexels.com/photos/96974/pexels-photo-96974.jpeg?h=350&auto=compress&cs=tinysrgb",
      },
      
      {
      id: "3",
      name: "柳橙汁3",
      description: "好喝柳橙汁",
      image_url: "https://images.pexels.com/photos/96974/pexels-photo-96974.jpeg?h=350&auto=compress&cs=tinysrgb",
      },
      
      {
      id: "4",
      name: "柳橙汁4",
      description: "好喝柳橙汁",
      image_url: "https://images.pexels.com/photos/96974/pexels-photo-96974.jpeg?h=350&auto=compress&cs=tinysrgb",
      }
      
      ]
  end
end
